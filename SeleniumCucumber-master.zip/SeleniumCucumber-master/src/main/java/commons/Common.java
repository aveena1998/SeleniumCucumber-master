package main.java.commons;

public class Common {

    public static class TestCount {
        public static int PASSCOUNT;
        public static int FAILCOUNT;
        public static int SKIPCOUNT;
    }

    public static class HookClass {
        public static String BROWSERNAME;
        public static String URL;
    }
}
