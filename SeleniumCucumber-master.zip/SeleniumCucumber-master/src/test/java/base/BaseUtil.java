package test.java.base;

import org.openqa.selenium.WebDriver;

public class BaseUtil {

    public static WebDriver driver;
}
